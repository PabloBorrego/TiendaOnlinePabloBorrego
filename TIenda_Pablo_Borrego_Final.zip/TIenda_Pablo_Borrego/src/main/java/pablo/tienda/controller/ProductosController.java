package pablo.tienda.controller;



import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import jxl.Workbook;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import pablo.tienda.LoginWSpringApplication;
import pablo.tienda.model.DetallesPedido;
import pablo.tienda.model.Producto;
import pablo.tienda.model.Usuario;
import pablo.tienda.service.CategoriaService;
import pablo.tienda.service.DetallesPedidoService;
import pablo.tienda.service.ProductoService;


@Controller
@RequestMapping("/productos")
public class ProductosController {

	@Autowired
	ProductoService ps;
	@Autowired
	DetallesPedidoService ds;
	@Autowired
	CategoriaService Cs;
	
	
	@GetMapping("")
	public String verProductos(Model mod, HttpSession session) {
		mod.addAttribute("listaCategorias",Cs.getListaCategorias());
		mod.addAttribute("listaProductos",ps.getListaProductos());
		return "productos/listaProductos";
	}
	
	@GetMapping("/verProducto/{id}")
	public String insertarProductos(Model mod, @PathVariable int id, HttpSession session) {
		
		LoginWSpringApplication.logger.info("Se muestra el producto en detalle");
		
		Producto p = ps.getById(id);
		mod.addAttribute("producto", p);
		return "productos/detalleProducto";
	}
	
	@GetMapping("/crear")
	public String nuevoProducto(Model model) {
		
		model.addAttribute("producto", new Producto());
		return "productos/altaProductos";
	}
	
	@PostMapping("/crear/submit")
	public String crear(@ModelAttribute Producto producto, @RequestParam("file") MultipartFile file) {
		try {
			if(!file.isEmpty()) {
				producto.setImagen(file.getOriginalFilename());
				
				ClassLoader loader = Thread.currentThread().getContextClassLoader();
			    URL appResourceURL = loader.getResource("static");
			    String dbConfigFileRoute = appResourceURL.getPath();
			    //dbConfigFileRoute = dbConfigFileRoute.substring(1, dbConfigFileRoute.length());
			    int separador = dbConfigFileRoute.lastIndexOf("/");
			    dbConfigFileRoute = dbConfigFileRoute.substring(1, separador);
			    String ruta = dbConfigFileRoute + "/static/img/" + file.getOriginalFilename();
			    
			    //guardar en el fichero
			    Files.copy(file.getInputStream(), Paths.get(ruta));
			    
			    
			}
		} catch (IOException e) {
			System.out.println(e);
			//throw new StorageException("Failed to store file " + file.getOriginalFilename(), e);
		}
		producto.setId_categoria(1);
		
		LoginWSpringApplication.logger.info("Se crea un producto nuevo");
		ps.addProducto(producto);
		return "redirect:/productos";
	}
	
	@GetMapping("/eliminar/{id}")
	public String eliminar(@PathVariable int id) {
		LoginWSpringApplication.logger.info("El administrador elemina un producto");
		ps.delProducto(id);
		return "redirect:/productos";
	}
	
	@GetMapping("/editar/{id}")
	public String actualizacionForm(@PathVariable int id, Model model) {
		Producto p = ps.getById(id);
		System.out.println(p.getId());
		model.addAttribute("producto",p);
		return "productos/editarProductos";
	}
	
	@GetMapping("/editar/submit")
	public String actualizar(@ModelAttribute Producto producto) {
		
		Producto p = ps.getById(producto.getId());
		
		p.setNombre(producto.getNombre());
		p.setPrecio(producto.getPrecio());
		p.setDescripcion(producto.getDescripcion());
		p.setStock(producto.getStock());
		
		LoginWSpringApplication.logger.info("Se edita un producto");
		
		ps.editProducto(p);
		
		return "redirect:/productos";
	}
	
	@GetMapping("/crearExcel")
	public String crearExcel(@ModelAttribute Producto producto) {
		File fichero = new File("nueva.xls");
		
        try {
        	WritableWorkbook w = Workbook.createWorkbook(fichero);
        	
        	//Nombre de la hoja
        	WritableSheet sheet = w.createSheet("Datos", 0);
        	
        	
        	SimpleDateFormat formato= new SimpleDateFormat("yyyy-MM-dd 'at' HH:mm:ss z");
        	Date date = new Date(System.currentTimeMillis());
        	
        	
        	jxl.write.Label fechaAlbaran = new jxl.write.Label(0, 0, formato.format(date));
        	sheet.addCell(fechaAlbaran);
        	
        	
        	ArrayList<Producto> listaProductos  = (ArrayList<Producto>) ps.getListaProductos(); 
        	
        	for(int i = 0; i <listaProductos.size();i++) {
        		
        		jxl.write.Number pId = new jxl.write.Number(1, i, listaProductos.get(i).getId());
        		sheet.addCell(pId);
            	jxl.write.Label pNombre = new jxl.write.Label(2, i, listaProductos.get(i).getNombre());
            	sheet.addCell(pNombre);
            	jxl.write.Label pDescripcion = new jxl.write.Label(3, i, listaProductos.get(i).getDescripcion());
            	sheet.addCell(pDescripcion);
            	jxl.write.Number pPrecio = new jxl.write.Number(4, i, listaProductos.get(i).getPrecio());
            	sheet.addCell(pPrecio);
            	jxl.write.Number pStock = new jxl.write.Number(5, i, listaProductos.get(i).getStock());
            	sheet.addCell(pStock);
        		
        	}
        	

            w.write();
            w.close();
        	
            LoginWSpringApplication.logger.info("Se crea un albarán en excel");
            
        } catch (Exception e) {
        	e.printStackTrace();
        }
		return "redirect:/productos";
		
	}
	
	@GetMapping("/addProductoCarrito/{id}")
	public String addProductoCarrito(Model mod, HttpSession sesion, @PathVariable int id) {
		
		Producto p = ps.getById(id);
		ArrayList<DetallesPedido> ar = (ArrayList<DetallesPedido>) sesion.getAttribute("carrito");
		int contadorStock = p.getStock();
		
		//Se comprueba si el producto existe dentro del carrito
		boolean existeEnCarrito = false;
		
		for(DetallesPedido d : ar) {
			if(d.getId_producto() == id) {
				existeEnCarrito = true;
			}
		}
		
		//Si existe se suma uno a las unidades del DetallePedido correspondiente
		if(existeEnCarrito == true && contadorStock > 0) {
			for(DetallesPedido d : ar) {
				if(d.getId_producto() == id) {
					contadorStock--;
					d.setUnidades(d.getUnidades()+1);
					d.setTotal(ds.calcularTotal(d, ps.getById(id)));
				}
			}
			 
			
		//Si no existe creamos un DetallePedido nuevo para el producto y iniciamos en 1 
		}else {
			if(contadorStock > 0) {
				DetallesPedido dp = new DetallesPedido(p.getId(),(int)p.getPrecio(),1, p.getImpuesto(), p.getPrecio());
				dp.setUnidades(1);
				dp.setTotal(ds.calcularTotal(dp, ps.getById(id)));
				dp.setNombreprod(ps.getById(p.getId()).getNombre());
				contadorStock--;
				ar.add(dp);
			}
		}
		 
		LoginWSpringApplication.logger.info("Se añade un producto al carrito");
		sesion.setAttribute("carrito", ar);
		
		return "redirect:/";
	}
	
}
