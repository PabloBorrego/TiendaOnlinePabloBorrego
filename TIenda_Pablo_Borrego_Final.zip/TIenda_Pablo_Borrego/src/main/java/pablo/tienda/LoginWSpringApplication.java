package pablo.tienda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

@SpringBootApplication
public class LoginWSpringApplication {

	public static Logger logger = LogManager.getLogger(LoginWSpringApplication.class);
	
	public static void main(String[] args) {
		
		SpringApplication.run(LoginWSpringApplication.class, args);
	}
	
	

}
